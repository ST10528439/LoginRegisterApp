/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginregisterapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ST10528439
 */
public class MessageTest {

    private final Message message = new Message();

    // ---------------------------------------------------------
    // 1. Message Length Tests
    // ---------------------------------------------------------
    @Test
    public void testMessageLengthSuccess() {
        String validMessage = "Hi Mike, can you join us for dinner tonight?";
        String expected = "Message ready to send.";
        String actual = message.checkMessageLength(validMessage);
        assertEquals(expected, actual);
    }

    @Test
    public void testMessageLengthFailure() {
        // Build string over 250 characters
        StringBuilder longMsg = new StringBuilder();
        for (int i = 0; i < 260; i++) {
            longMsg.append("a");
        }
        
        String actual = message.checkMessageLength(longMsg.toString());
        assertTrue(actual.contains("Message exceeds 250 characters by 10"));
    }

    // ---------------------------------------------------------
    // 2. Recipient Cell Phone Formatting Tests
    // ---------------------------------------------------------
    @Test
    public void testRecipientCellSuccess() {
        String testCell = "+27718693002";
        String expected = "Cell phone number successfully captured.";
        String actual = message.checkRecipientCell(testCell);
        assertEquals(expected, actual);
    }

    @Test
    public void testRecipientCellFailure() {
        String testCell = "08575975889";
        String expected = "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        String actual = message.checkRecipientCell(testCell);
        assertEquals(expected, actual);
    }

    // ---------------------------------------------------------
    // 3. Message Hash Generation Test
    // ---------------------------------------------------------
    @Test
    public void testMessageHashCreation() {
        // Test Data 1: ID = 00..., Count = 0, Msg = "Hi Mike, can you join us for dinner tonight?"
        String customID = "0012345678";
        int count = 0;
        String text = "Hi Mike, can you join us for dinner tonight?";

        String expectedHash = "00:0:HITONIGHT";
        String actualHash = message.createMessageHashForTest(customID, count, text);

        assertEquals(expectedHash, actualHash);
    }

    // ---------------------------------------------------------
    // 4. Message Action Options Tests
    // ---------------------------------------------------------
    @Test
    public void testSentMessageOptionSend() {
        String expected = "Message successfully sent.";
        String actual = message.SentMessage("1");
        assertEquals(expected, actual);
    }

    @Test
    public void testSentMessageOptionDisregard() {
        String expected = "Press 0 to delete the message.";
        String actual = message.SentMessage("2");
        assertEquals(expected, actual);
    }

    @Test
    public void testSentMessageOptionStore() {
        String expected = "Message successfully stored.";
        String actual = message.SentMessage("3");
        assertEquals(expected, actual);
    }
}
