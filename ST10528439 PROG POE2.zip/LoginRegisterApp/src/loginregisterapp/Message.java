/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginregisterapp;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

/**
 *
 * @author ST10528439
 */
public class Message {

    private String messageID;
    private static int messageCount = 0;
    private String recipientCell;
    private String messagePayload;
    private String messageHash;

    // Default Constructor
    public Message() {
        this.messageID = generateRandomID();
    }

    // Parameterized Constructor
    public Message(String recipientCell, String messagePayload) {
        this.messageID = generateRandomID();
        this.recipientCell = recipientCell;
        this.messagePayload = messagePayload;
        this.messageHash = createMessageHash();
    }

    // Generates a random 10-digit Message ID
    private String generateRandomID() {
        Random rand = new Random();
        long num = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(num);
    }

    // Checks if Message ID is 10 characters or fewer
    public boolean checkMessageID() {
        return this.messageID != null && this.messageID.length() <= 10;
    }

    // Validates recipient cell number format
    public String checkRecipientCell(String cellNumber) {
        if (cellNumber != null && cellNumber.startsWith("+") && cellNumber.length() <= 12) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Validates message length limit (<= 250 characters)
    public String checkMessageLength(String message) {
        if (message == null) return "Invalid message.";
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int over = message.length() - 250;
            return "Message exceeds 250 characters by " + over + "; please reduce the size.";
        }
    }

    // Autogenerates the Message Hash (Format: ID_PREFIX:COUNT:FIRST_WORD_LAST_WORD)
    public String createMessageHash() {
        if (this.messagePayload == null || this.messagePayload.trim().isEmpty() || this.messageID == null) {
            return "";
        }

        // First two digits of Message ID
        String prefix = this.messageID.substring(0, Math.min(2, this.messageID.length()));

        // Split message into words
        String[] words = this.messagePayload.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        // Combine and convert to upper case
        String rawHash = prefix + ":" + messageCount + ":" + firstWord + lastWord;
        return rawHash.toUpperCase();
    }

    // Custom hash generator for specific unit testing
    public String createMessageHashForTest(String customID, int count, String messageText) {
        String prefix = customID.substring(0, Math.min(2, customID.length()));
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        // Strip punctuation from words for standard clean hashing
        firstWord = firstWord.replaceAll("[^a-zA-Z0-9]", "");
        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");

        return (prefix + ":" + count + ":" + firstWord + lastWord).toUpperCase();
    }

    // Choice selector for Sending, Disregarding, or Storing
    public String SentMessage(String choice) {
        switch (choice) {
            case "1":
            case "Send Message":
            case "Send":
                messageCount++;
                return "Message successfully sent.";

            case "2":
            case "Disregard Message":
            case "Disregard":
                return "Press 0 to delete the message.";

            case "3":
            case "Store Message":
            case "Store":
                storeMessage();
                return "Message successfully stored.";

            default:
                return "Invalid choice selected.";
        }
    }

    // Displays all details of sent messages
    public String printMessages() {
        return "Message ID: " + this.messageID + "\n"
             + "Message Hash: " + this.messageHash + "\n"
             + "Recipient: " + this.recipientCell + "\n"
             + "Message: " + this.messagePayload;
    }

    // Returns cumulative total of sent messages
    public int returnTotalMessages() {
        return messageCount;
    }

    // Stores message in JSON format to file
    public void storeMessage() {
        String jsonPayload = "{\n"
                + "  \"messageID\": \"" + this.messageID + "\",\n"
                + "  \"recipient\": \"" + this.recipientCell + "\",\n"
                + "  \"message\": \"" + this.messagePayload + "\",\n"
                + "  \"messageHash\": \"" + this.messageHash + "\"\n"
                + "}";

        try (FileWriter writer = new FileWriter("stored_messages.json", true)) {
            writer.write(jsonPayload + "\n");
        } catch (IOException e) {
            System.err.println("Error saving message to JSON: " + e.getMessage());
        }
    }

    // Getters and Setters
    public String getMessageID() { return messageID; }
    public void setMessageID(String messageID) { this.messageID = messageID; }
    public String getRecipientCell() { return recipientCell; }
    public void setRecipientCell(String recipientCell) { this.recipientCell = recipientCell; }
    public String getMessagePayload() { return messagePayload; }
    public void setMessagePayload(String messagePayload) { this.messagePayload = messagePayload; }
    public String getMessageHash() { return messageHash; }
}

