/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loginregisterapp;

import java.util.Scanner;

/**
 * Main application entry point for the QuickChat system.
 * Manages user registration, login authentication, and the main messaging menu.
 * 
 * @author ST10528439
 */
public class LoginRegisterApp {

    /**
     * Executes the application flow.
     * 
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            Login loginSystem = new Login();

            System.out.println("=== Welcome to the Chat App Registration ===");

            System.out.print("Enter First Name: ");
            String firstName = scanner.nextLine();

            System.out.print("Enter Last Name: ");
            String lastName = scanner.nextLine();

            System.out.print("Enter Username (must contain '_' and be <= 5 chars): ");
            String username = scanner.nextLine();

            System.out.print("Enter Password (8+ chars, 1 Capital, 1 Number, 1 Special): ");
            String password = scanner.nextLine();

            System.out.print("Enter Cell Phone Number (e.g., +27838968976): ");
            String cellNumber = scanner.nextLine();

            String registrationMessage = loginSystem.registerUser(username, password, cellNumber, firstName, lastName);
            System.out.println("\n--- Registration Status ---");
            System.out.println(registrationMessage);

            // Proceed to Login only if registration succeeded
            if (registrationMessage.contains("successfully")) {

                System.out.println("\n=== Login ===");
                System.out.print("Enter Username: ");
                String loginUser = scanner.nextLine();

                System.out.print("Enter Password: ");
                String loginPass = scanner.nextLine();

                boolean isAuthenticated = loginSystem.loginUser(loginUser, loginPass);
                String loginStatusMessage = loginSystem.returnLoginStatus(isAuthenticated);

                System.out.println("\n--- Login Status ---");
                System.out.println(loginStatusMessage);

                // If logged in successfully, open QuickChat menu
                if (isAuthenticated) {
                    System.out.println("\nWelcome to QuickChat.");

                    boolean running = true;
                    while (running) {
                        System.out.println("\nPlease choose an option:");
                        System.out.println("1) Send Messages");
                        System.out.println("2) Show recently sent messages");
                        System.out.println("3) Quit");
                        System.out.print("Option: ");

                        String choice = scanner.nextLine();

                        switch (choice) {
                            case "1":
                                System.out.print("How many messages would you like to enter? ");
                                try {
                                    int numMessages = Integer.parseInt(scanner.nextLine());

                                    for (int i = 0; i < numMessages; i++) {
                                        System.out.println("\n--- Message " + (i + 1) + " ---");
                                        System.out.print("Enter Recipient Cell Number: ");
                                        String recipient = scanner.nextLine();

                                        System.out.print("Enter Message Payload: ");
                                        String payload = scanner.nextLine();

                                        Message msg = new Message(recipient, payload);

                                        // Validate cell number
                                        String cellCheck = msg.checkRecipientCell(recipient);
                                        System.out.println(cellCheck);

                                        // Validate message length
                                        String lenCheck = msg.checkMessageLength(payload);
                                        System.out.println(lenCheck);

                                        if (lenCheck.equals("Message ready to send.")) {
                                            // Display actions menu
                                            System.out.println("\nChoose action for this message:");
                                            System.out.println("1) Send Message");
                                            System.out.println("2) Disregard Message");
                                            System.out.println("3) Store Message");
                                            System.out.print("Action choice: ");
                                            String actionChoice = scanner.nextLine();

                                            String result = msg.SentMessage(actionChoice);
                                            System.out.println(result);

                                            if (actionChoice.equals("1") || actionChoice.equalsIgnoreCase("Send")) {
                                                System.out.println("\n--- Message Summary ---");
                                                System.out.println(msg.printMessages());
                                            }
                                        }
                                    }
                                } catch (NumberFormatException e) {
                                    System.out.println("Invalid input. Please enter a valid number.");
                                }
                                break;

                            case "2":
                                System.out.println("Coming Soon.");
                                break;

                            case "3":
                                System.out.println("Exiting QuickChat. Goodbye!");
                                running = false;
                                break;

                            default:
                                System.out.println("Invalid option. Please enter 1, 2, or 3.");
                                break;
                        }
                    }
                }

            } else {
                System.out.println("\nRegistration failed. Please restart the application and try again.");
            }
        }
    }
}