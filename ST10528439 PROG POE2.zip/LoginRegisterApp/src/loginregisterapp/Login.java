/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginregisterapp;

/**
 * Handles user registration, credentials validation, and authentication status.
 * 
 * @author ST10528439
 */
public class Login {

    private String storedUsername;
    private String storedPassword;
    private String storedCellNumber;
    private String userFirstName;
    private String userLastName;

    /**
     * Checks if the username contains an underscore and is 5 characters or fewer.
     * 
     * @param username The entered username.
     * @return true if valid, false otherwise.
     */
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    /**
     * Verifies password complexity: length >= 8, includes uppercase letter, digit, 
     * and special character (including ~ and `).
     * 
     * @param password The entered password.
     * @return true if valid, false otherwise.
     */
    public boolean checkPasswordComplexity(String password) {
        if (password == null) return false;
        
        boolean hasLength = password.length() >= 8;
        boolean hasCapital = !password.equals(password.toLowerCase());
        boolean hasNumber = password.matches(".*\\d.*");
        // Updated regex to include ~ and ` as special characters based on lecturer feedback
        boolean hasSpecial = password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?~`].*");
        
        return hasLength && hasCapital && hasNumber && hasSpecial;
    }

    /**
     * Validates South African cell phone numbers with +27 country code and 9 national digits.
     * 
     * Reference: Regular expression pattern adapted for SA international numbers (+27).
     * Source: https://stackoverflow.com/questions/4058001/validate-south-africa-cell-phone-number 
     * Accessed: 16 September 2026
     * 
     * @param cellNumber The entered phone number.
     * @return true if valid, false otherwise.
     */
    public boolean checkCellPhoneNumber(String cellNumber) {
        if (cellNumber == null) return false;
        // Strictly enforces +27 prefix followed by exactly 9 digits
        String regex = "^\\+27[0-9]{9}$";
        return cellNumber.matches(regex);
    }

    /**
     * Registers a user if username, password, and cell phone number pass validation.
     * 
     * @param username User username.
     * @param password User password.
     * @param cellNumber User phone number.
     * @param firstName User first name.
     * @param lastName User last name.
     * @return Status message string.
     */
    public String registerUser(String username, String password, String cellNumber, String firstName, String lastName) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        
        if (!checkCellPhoneNumber(cellNumber)) {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }

        this.storedUsername = username;
        this.storedPassword = password;
        this.storedCellNumber = cellNumber;
        this.userFirstName = firstName;
        this.userLastName = lastName;

        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    /**
     * Checks if entered credentials match stored credentials.
     * 
     * @param username Entered username.
     * @param password Entered password.
     * @return true if authentication succeeds, false otherwise.
     */
    public boolean loginUser(String username, String password) {
        return username != null && password != null 
               && username.equals(this.storedUsername) 
               && password.equals(this.storedPassword);
    }

    /**
     * Returns formatted user greeting upon login status.
     * 
     * @param isLoggedIn Boolean result of login attempt.
     * @return Welcome or failure message.
     */
    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + this.userFirstName + ", " + this.userLastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Getters
    public String getStoredUsername() { return storedUsername; }
    public String getStoredPassword() { return storedPassword; }
    public String getStoredCellNumber() { return storedCellNumber; }
}